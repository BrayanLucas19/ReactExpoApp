import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { Appbar, Drawer } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TelaLogin from './TelaLogin';
import SegundaTela from './SegundaTela';
import TelaDetalhes from './TelaDetalhes';
import Cart from './carrinho';
import TelaCadastro from './TelaCadastro';
import { useState } from 'react';

export default function App() {
  return (
    <NavigationContainer>
        <MyStack />
    </NavigationContainer>
  );
}

const Stack = createNativeStackNavigator();

function barra({navigation, back}){
  return(
    <Appbar.Header style={{backgroundColor: '#7F00E3', zIndex: 0}}>
      <Appbar.Action style={{alignItems: 'center'}} iconColor='white' icon='menu'/>
      <Appbar.Content style={{alignItems: 'center',}} title='Book Shop' color='white'
      titleStyle={{fontSize: 25}}
      onPress={() => navigation.navigate('TelaDeLista')}/>
      <Appbar.Action style={{alignItems: 'flex-end'}} iconColor='white' icon='cart'
      onPress={() => navigation.navigate('TelaDeCarrinho')}/>
    </Appbar.Header>
  );
}

function barraTelaDeDetalhes({navigation,back}){
  return(
  <Appbar.Header style={{backgroundColor: '#7F00E3'}}>
    {back ? <Appbar.BackAction onPress={navigation.goBack} 
    style={{alignItems: 'flex-start'}} iconColor='white' /> :null}
    <Appbar.Content style={{alignItems: 'center'}} 
    title='Detalhes' titleStyle={{fontSize: 25}} color='white' />
    <Appbar.Action icon='cart' style={{alignItems: 'flex-end'}} iconColor='white' 
    onPress={() => navigation.navigate('TelaDeCarrinho')}/>
  </Appbar.Header>
)}

function barraTelaCarrinho({navigation,back}){
  return(
  <Appbar.Header style={{backgroundColor: '#7F00E3'}}>
    {back ? <Appbar.BackAction onPress={navigation.goBack} 
    style={{alignItems: 'flex-start'}} iconColor='white' /> :null}
    <Appbar.Content style={{alignItems: 'center'}} 
    title='Carrinho' titleStyle={{fontSize: 25}} color='white' />
  </Appbar.Header>
)}

function MyStack(){

  const [carrinho, setCarrinho] = useState([]);

  function addProduto(produto){
    carrinho.push(produto);
    console.log(carrinho.length);
  }
  return(
    <Stack.Navigator
    initialRouteName='TelaLogin'>
      <Stack.Screen name="TelaDeLogin" component={TelaLogin} options={{headerShown: false}} />
      <Stack.Screen name="TelaDeLista" component={SegundaTela} options={{header:barra}} />
      <Stack.Screen name="TelaDeCarrinho" component={Cart} options={{header:barraTelaCarrinho}}/>
      <Stack.Screen name="Detalhes" component={TelaDetalhes} options={{header:barraTelaDeDetalhes}}/>
      <Stack.Screen name="TelaCadastro" component={TelaCadastro} options={{headerShown: false}}/>
    </Stack.Navigator>
  );
}






const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
