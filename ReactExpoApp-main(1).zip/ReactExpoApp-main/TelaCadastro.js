import React from "react";
import { Text, Button, TextInput } from "react-native-paper";
import { View } from "react-native";

export default function TelaCadastro (navigation){
    return(
        <View style={{flex: 1, backgroundColor: '#7F00E3', alignItems: 'center'}}>
            <View style={{paddingTop: 110}}>
                <Text style={{fontSize: 20, color: 'white'}}>Cadastro</Text>
            </View>
            <View>
                <TextInput mode="outlined" outlineColor="#6C00E3" label='Nome Completo' 
                outlineStyle={{paddingTop: 20, width: 300}}></TextInput>
                
                <TextInput mode="outlined" outlineColor="#6C00E3" label='Nome de usuario' 
                outlineStyle={{paddingTop: 20, width: 300}}></TextInput>
                
                <TextInput mode="outlined" outlineColor="#6C00E3" label='Email' 
                outlineStyle={{paddingTop: 20, width: 300}}></TextInput>
                
                <TextInput mode="outlined" outlineColor="#6C00E3" label='Telefone' 
                outlineStyle={{paddingTop: 20, width: 300}}></TextInput>
                
                <TextInput mode="outlined" outlineColor="#6C00E3" label='Senha' 
                outlineStyle={{paddingTop: 20, width: 300}}></TextInput>
                
                <TextInput mode="outlined" outlineColor="#6C00E3" label='Confirme a senha' 
                outlineStyle={{paddingTop: 20, width: 300}}></TextInput>

                <Button style={{backgroundColor:'black'}} textColor='white'
                onPress={() => navigation.navigate('TelaDeLogin')}>Cadastrar-se</Button>
                
            </View>
        </View>
    );
}