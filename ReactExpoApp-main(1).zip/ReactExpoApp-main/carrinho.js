import React from "react";
import { View } from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { Button, Card, IconButton, Paragraph, Text, Title } from "react-native-paper";

export default function Cart({ route, navigation }){
    const { carrinho } = route.params;
    console.log(carrinho?.length);

    return(
        <View style={{ alignItems: 'center',justifyContent: 'center', paddingTop: 25 }}>
            <FlatList
                data={carrinho}
                numColumns={2}
                renderItem={({ item }) => (
                    <View>
                        <Card style={{ margin: 4, width: 165}} onPress={() => navigation.navigate('Detalhes', { id: item.id })}>                      
                            <Card.Cover source={{uri: item.imagem}} /> 
                            <IconButton
                              icon='heart' iconColor='white'  size={20} onPress={() => console.log('Apertei')} 
                              style={{position: 'absolute'}}/>

                            <Card.Content style={{height: 100}}>
                                <Title>{item.titulo}</Title>
                                <Paragraph>{item.autor}</Paragraph>
                            </Card.Content>
                        
                        </Card>
        
                    </View>

                )}
            />
      </View>
    )
}